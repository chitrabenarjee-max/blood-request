from datetime import datetime
from flask import Blueprint, render_template, redirect, url_for, flash, request
from flask_login import login_user, logout_user, login_required, current_user
from models import db
from models.user import User
from models.donor import Donor
from models.recipient import Recipient
from data_locations import lookup_location

auth_bp = Blueprint("auth", __name__)

@auth_bp.route("/login", methods=["GET", "POST"])
def login():
    if current_user.is_authenticated:
        return redirect(url_for("index"))
    if request.method == "POST":
        email = request.form.get("email", "").strip().lower()
        password = request.form.get("password", "")
        user = User.query.filter_by(email=email).first()
        if not user or not user.check_password(password) or user.account_status != "Active":
            flash("Invalid credentials or disabled account.", "danger")
            return render_template("login.html")
        login_user(user)
        if user.role == "donor":
            return redirect(url_for("donor.dashboard"))
        if user.role == "recipient":
            return redirect(url_for("recipient.dashboard"))
        return redirect(url_for("admin.dashboard"))
    return render_template("login.html")

@auth_bp.route("/register", methods=["GET", "POST"])
def register():
    if request.method == "POST":
        try:
            name = request.form["full_name"].strip()
            email = request.form["email"].strip().lower()
            if User.query.filter_by(email=email).first():
                flash("Email already registered.", "warning")
                return render_template("register.html")
            password = request.form.get("password", "")
            confirm_password = request.form.get("confirm_password", "")
            if password != confirm_password:
                flash("Password and confirm password do not match.", "danger")
                return render_template("register.html")
            if len(password) < 8:
                flash("Password must be at least 8 characters.", "danger")
                return render_template("register.html")
            role = request.form["role"]
            if role not in ("donor", "recipient"):
                raise ValueError("Invalid role.")
            blood = request.form["blood_group"]
            dob = datetime.strptime(request.form["date_of_birth"], "%Y-%m-%d").date()
            city = request.form["city"].strip()
            area = request.form["area"].strip()
            coords = lookup_location(city, area)
            if coords:
                lat, lon = coords
            else:
                try:
                    lat = float(request.form.get("latitude") or 17.3850)
                    lon = float(request.form.get("longitude") or 78.4867)
                except ValueError:
                    raise ValueError("Invalid coordinates")
            user = User(full_name=name, email=email, phone=request.form["phone"].strip(),
                        role=role, blood_group=blood, city=city, area=area,
                        latitude=lat, longitude=lon, date_of_birth=dob)
            user.set_password(password)
            db.session.add(user)
            db.session.flush()
            if role == "donor":
                db.session.add(Donor(user_id=user.id, availability="Available"))
            else:
                db.session.add(Recipient(user_id=user.id))
            db.session.commit()
            flash("Registration successful. Please log in.", "success")
            return redirect(url_for("auth.login"))
        except Exception as e:
            db.session.rollback()
            flash("Please check the form values and try again.", "danger")
    return render_template("register.html")

@auth_bp.route("/logout")
@login_required
def logout():
    logout_user()
    return redirect(url_for("index"))
