from flask import Blueprint, render_template, redirect, url_for
from flask_login import login_required, current_user
from models.donor_request import DonorRequest
from models.blood_request import BloodRequest

recipient_bp = Blueprint("recipient", __name__, url_prefix="/recipient")

@recipient_bp.route("/dashboard")
@login_required
def dashboard():
    if current_user.role != "recipient": return redirect(url_for("index"))
    requests = current_user.recipient.blood_requests
    return render_template("recipient_dashboard.html", requests=requests)

@recipient_bp.route("/requests")
@login_required
def requests():
    if current_user.role != "recipient": return redirect(url_for("index"))
    return render_template("requests.html", requests=current_user.recipient.blood_requests)
