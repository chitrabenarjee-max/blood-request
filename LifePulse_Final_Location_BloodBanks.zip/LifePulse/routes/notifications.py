from flask import Blueprint, render_template, redirect, url_for, flash
from flask_login import login_required, current_user
from models import db
from models.notification import Notification

notifications_bp = Blueprint("notifications", __name__, url_prefix="/notifications")

@notifications_bp.route("")
@login_required
def index():
    notes = Notification.query.filter_by(user_id=current_user.id).order_by(Notification.created_at.desc()).all()
    return render_template("notifications.html", notifications=notes)

@notifications_bp.route("/api")
@login_required
def api_notifications():
    from flask import jsonify
    notes = Notification.query.filter_by(user_id=current_user.id).order_by(Notification.created_at.desc()).all()
    return jsonify([{"id": n.id, "message": n.message, "type": n.type, "is_read": n.is_read} for n in notes])

@notifications_bp.route("/read/<int:notification_id>", methods=["POST"])
@login_required
def read(notification_id):
    n = Notification.query.filter_by(id=notification_id, user_id=current_user.id).first_or_404()
    n.is_read = True
    db.session.commit()
    return redirect(url_for("notifications.index"))
