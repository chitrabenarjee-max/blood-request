from datetime import datetime
from flask import Blueprint, render_template, redirect, url_for, flash, request, jsonify
from flask_login import login_required, current_user
from models import db
from models.blood_request import BloodRequest
from models.donor_request import DonorRequest
from models.donor import Donor
from services.matching import rank_donors, DISCLAIMER
from services.notification_service import notify

requests_bp = Blueprint("requests", __name__)

@requests_bp.route("/requests/create", methods=["GET", "POST"])
@login_required
def create_request():
    if current_user.role != "recipient": return redirect(url_for("index"))
    if request.method == "POST":
        try:
            r = BloodRequest(
                recipient_id=current_user.recipient.id,
                blood_group=request.form["blood_group"],
                units=max(1, int(request.form["units"])),
                urgency=request.form["urgency"],
                hospital_name=request.form["hospital_name"].strip(),
                hospital_address=request.form["hospital_address"].strip(),
                city=request.form["city"].strip(),
                latitude=float(request.form.get("latitude") or current_user.latitude or 17.385),
                longitude=float(request.form.get("longitude") or current_user.longitude or 78.487),
                required_date=datetime.strptime(request.form["required_date"], "%Y-%m-%d").date(),
                required_time=datetime.strptime(request.form["required_time"], "%H:%M").time(),
                notes=request.form.get("notes", "").strip()
            )
            db.session.add(r)
            db.session.commit()
            for donor, _ in rank_donors(Donor.query.all(), r):
                notify(donor.user_id, f"New {r.urgency.lower()} blood request available near {r.city}. Please review it in LifePulse.", "request", "LifePulse: New Blood Request")
            flash("Blood request created successfully.", "success")
            return redirect(url_for("requests.match", request_id=r.id))
        except Exception:
            db.session.rollback()
            flash("Invalid request details. Please check the form.", "danger")
    return render_template("create_request.html")

@requests_bp.route("/requests/<int:request_id>/match")
@login_required
def match(request_id):
    r = BloodRequest.query.get_or_404(request_id)
    if current_user.role != "admin" and r.recipient.user_id != current_user.id:
        flash("Unauthorized access.", "danger")
        return redirect(url_for("index"))
    matches = rank_donors(Donor.query.all(), r)
    sent_ids = {x.donor_id for x in r.donor_requests if x.status != "Rejected"}
    return render_template("donors.html", request_obj=r, matches=matches, sent_ids=sent_ids, disclaimer=DISCLAIMER)

@requests_bp.route("/requests/<int:request_id>/send/<int:donor_id>", methods=["POST"])
@login_required
def send_request(request_id, donor_id):
    if current_user.role != "recipient": return redirect(url_for("index"))
    r = BloodRequest.query.filter_by(id=request_id, recipient_id=current_user.recipient.id).first_or_404()
    donor = Donor.query.get_or_404(donor_id)
    existing = DonorRequest.query.filter_by(blood_request_id=r.id, donor_id=donor.id).first()
    if existing:
        flash("A request already exists for this donor.", "warning")
    else:
        dr = DonorRequest(recipient_id=current_user.recipient.id, donor_id=donor.id, blood_request_id=r.id)
        db.session.add(dr)
        notify(donor.user_id, f"New donor request from {current_user.full_name}. Please review it in LifePulse.", "request", "LifePulse: New Donor Request")
        db.session.commit()
        flash("Donor request sent.", "success")
    return redirect(url_for("requests.match", request_id=r.id))

@requests_bp.route("/api/donors")
def api_donors():
    group = request.args.get("blood_group")
    city = request.args.get("city")
    available = request.args.get("availability")
    q = Donor.query.join(Donor.user)
    if group: q = q.filter(Donor.user.has(blood_group=group))
    if city: q = q.filter(Donor.user.has(city=city))
    if available: q = q.filter(Donor.availability == available)
    data = []
    for d in q.all():
        data.append({"id": d.id, "name": d.user.full_name, "blood_group": d.user.blood_group,
                     "city": d.user.city, "area": d.user.area, "availability": d.availability})
    return jsonify(data)

@requests_bp.route("/api/donors/match")
@login_required
def api_match():
    request_id = request.args.get("request_id", type=int)
    r = BloodRequest.query.get_or_404(request_id)
    if current_user.role != "admin" and r.recipient.user_id != current_user.id:
        return jsonify({"error": "Unauthorized"}), 403
    return jsonify([{"donor_id": d.id, "name": d.user.full_name, "blood_group": d.user.blood_group,
                     "city": d.user.city, "distance_km": round(dist, 1) if dist is not None else None,
                     "availability": d.availability, "match_status": DISCLAIMER}
                    for d, dist in rank_donors(Donor.query.all(), r)])

@requests_bp.route("/api/requests", methods=["GET", "POST"])
@login_required
def api_requests():
    if request.method == "GET":
        if current_user.role == "recipient":
            rs = current_user.recipient.blood_requests
        elif current_user.role == "admin":
            rs = BloodRequest.query.all()
        else:
            return jsonify({"error": "Recipient/admin access required"}), 403
        return jsonify([{"id": r.id, "blood_group": r.blood_group, "units": r.units,
                         "urgency": r.urgency, "status": r.status, "city": r.city} for r in rs])
    return jsonify({"error": "Use the HTML form for CSRF-protected request creation."}), 405

@requests_bp.route("/api/donor-requests", methods=["POST"])
@login_required
def api_donor_requests():
    data = request.get_json(silent=True) or {}
    if current_user.role != "recipient":
        return jsonify({"error": "Recipient access required"}), 403
    dr = DonorRequest(recipient_id=current_user.recipient.id,
                      donor_id=int(data["donor_id"]), blood_request_id=int(data["blood_request_id"]))
    db.session.add(dr)
    db.session.commit()
    return jsonify({"id": dr.id, "status": dr.status}), 201

@requests_bp.route("/api/donor-requests/<int:request_id>", methods=["PUT"])
@login_required
def api_donor_response(request_id):
    dr = DonorRequest.query.get_or_404(request_id)
    if current_user.role != "donor" or dr.donor.user_id != current_user.id:
        return jsonify({"error": "Unauthorized"}), 403
    status = (request.get_json(silent=True) or {}).get("status")
    if status not in ("Accepted", "Rejected"):
        return jsonify({"error": "Status must be Accepted or Rejected"}), 400
    dr.status = status
    dr.response_time = datetime.utcnow()
    db.session.commit()
    return jsonify({"id": dr.id, "status": dr.status})
