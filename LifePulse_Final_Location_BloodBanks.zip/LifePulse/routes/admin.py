from flask import Blueprint, render_template, redirect, url_for, flash, request
from flask_login import login_required, current_user
from models import db
from models.user import User
from models.donor import Donor
from models.recipient import Recipient
from models.blood_request import BloodRequest
from models.donor_request import DonorRequest
from models.blood_bank import BloodBank
from models.screening import Screening
from services.notification_service import notify_user

admin_bp = Blueprint("admin", __name__, url_prefix="/admin")

def admin_only():
    return current_user.is_authenticated and current_user.role == "admin"

@admin_bp.route("/dashboard")
@login_required
def dashboard():
    if not admin_only(): return redirect(url_for("index"))
    stats = {
        "users": User.query.count(), "donors": Donor.query.count(),
        "recipients": Recipient.query.count(),
        "active_requests": BloodRequest.query.filter(BloodRequest.status.in_(["Pending","Accepted"])).count(),
        "pending_requests": DonorRequest.query.filter_by(status="Pending").count(),
        "verified_banks": BloodBank.query.filter_by(verification_status="Verified").count()
    }
    return render_template("admin_dashboard.html", stats=stats,
                           users=User.query.order_by(User.id.desc()).limit(30).all(),
                           banks=BloodBank.query.all(), screenings=Screening.query.order_by(Screening.id.desc()).all())

@admin_bp.route("/bank/add", methods=["POST"])
@login_required
def add_bank():
    if not admin_only(): return redirect(url_for("index"))
    try:
        b = BloodBank(name=request.form["name"], license_id=request.form["license_id"],
                      address=request.form["address"], city=request.form["city"],
                      phone=request.form["phone"], email=request.form["email"],
                      latitude=float(request.form.get("latitude") or 17.385),
                      longitude=float(request.form.get("longitude") or 78.487),
                      verification_status="Pending")
        db.session.add(b); db.session.commit()
        flash("Blood bank added.", "success")
    except Exception:
        db.session.rollback(); flash("Could not add blood bank.", "danger")
    return redirect(url_for("admin.dashboard"))

@admin_bp.route("/bank/<int:bank_id>/verify", methods=["POST"])
@login_required
def verify_bank(bank_id):
    if not admin_only(): return redirect(url_for("index"))
    b = BloodBank.query.get_or_404(bank_id)
    b.verification_status = "Verified"
    db.session.commit()
    for u in User.query.filter(User.role.in_(["donor", "recipient"])).all():
        notify_user(u, f"Verified blood bank: {b.name} in {b.city}. Please use the licensed facility for medical screening and donation coordination.", "success", "LifePulse: Blood Bank Verified")
    db.session.commit()
    flash("Blood bank marked Verified. Notifications sent where delivery is configured.", "success")
    return redirect(url_for("admin.dashboard"))

@admin_bp.route("/user/<int:user_id>/disable", methods=["POST"])
@login_required
def disable_user(user_id):
    if not admin_only(): return redirect(url_for("index"))
    u = User.query.get_or_404(user_id)
    if u.id == current_user.id:
        flash("You cannot disable your own admin account.", "warning")
    else:
        u.account_status = "Disabled"; db.session.commit()
        notify_user(u, "Your LifePulse account has been disabled by an administrator.", "warning", "LifePulse: Account Disabled")
        db.session.commit(); flash("Account disabled.", "success")
    return redirect(url_for("admin.dashboard"))

@admin_bp.route("/user/<int:user_id>/enable", methods=["POST"])
@login_required
def enable_user(user_id):
    if not admin_only(): return redirect(url_for("index"))
    u=User.query.get_or_404(user_id)
    u.account_status="Active"; db.session.commit()
    flash("Account enabled successfully.", "success")
    return redirect(url_for("admin.dashboard"))

@admin_bp.route("/screenings")
@login_required
def screenings():
    if not admin_only(): return redirect(url_for("index"))
    return render_template("screening.html", screenings=Screening.query.order_by(Screening.id.desc()).all())
