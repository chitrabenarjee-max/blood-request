from flask import Blueprint, render_template
from models.blood_bank import BloodBank

blood_bank_bp = Blueprint("blood_bank", __name__, url_prefix="/blood-banks")

@blood_bank_bp.route("")
def list_banks():
    banks = BloodBank.query.order_by(BloodBank.verification_status.desc(), BloodBank.name).all()
    return render_template("blood_banks.html", banks=banks)

@blood_bank_bp.route("/api")
def api_banks():
    from flask import jsonify
    return jsonify([{"id": b.id, "name": b.name, "address": b.address, "city": b.city,
                     "phone": b.phone, "verification_status": b.verification_status} for b in BloodBank.query.all()])
