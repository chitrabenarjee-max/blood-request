from datetime import datetime
from flask import Blueprint, render_template, redirect, url_for, flash, request
from flask_login import login_required, current_user
from models import db
from models.donor import Donor
from models.donor_request import DonorRequest
from models.notification import Notification
from services.notification_service import notify

donor_bp = Blueprint("donor", __name__, url_prefix="/donor")

def donor_only():
    return current_user.is_authenticated and current_user.role == "donor"

@donor_bp.route("/dashboard")
@login_required
def dashboard():
    if not donor_only(): return redirect(url_for("index"))
    donor = current_user.donor
    reqs = donor.requests
    return render_template("donor_dashboard.html", donor=donor, requests=reqs)

@donor_bp.route("/availability/<status>", methods=["POST"])
@login_required
def availability(status):
    if not donor_only(): return redirect(url_for("index"))
    if status not in ("Available", "Unavailable"): return redirect(url_for("donor.dashboard"))
    current_user.donor.availability = status
    db.session.commit()
    flash(f"Availability changed to {status}.", "success")
    return redirect(url_for("donor.dashboard"))

@donor_bp.route("/requests")
@login_required
def requests():
    if not donor_only(): return redirect(url_for("index"))
    return render_template("donor_requests.html", requests=current_user.donor.requests)

@donor_bp.route("/requests/<int:request_id>/<action>", methods=["POST"])
@login_required
def respond(request_id, action):
    if not donor_only(): return redirect(url_for("index"))
    dr = DonorRequest.query.filter_by(id=request_id, donor_id=current_user.donor.id).first_or_404()
    if dr.status != "Pending" or action not in ("accept", "reject"):
        flash("This request can no longer be changed.", "warning")
        return redirect(url_for("donor.requests"))
    dr.status = "Accepted" if action == "accept" else "Rejected"
    dr.response_time = datetime.utcnow()
    if action == "accept":
        notify(dr.recipient.user_id, "Your donor request was accepted. Please proceed through a verified blood bank/hospital for medical screening and donation coordination.", "success", "LifePulse: Donor Request Accepted")
        flash("Request accepted. Medical screening must be completed at a verified blood bank.", "success")
    else:
        notify(dr.recipient.user_id, "Your donor request was rejected by the donor.", "warning", "LifePulse: Donor Request Update")
        flash("Request rejected.", "info")
    db.session.commit()
    return redirect(url_for("donor.requests"))
