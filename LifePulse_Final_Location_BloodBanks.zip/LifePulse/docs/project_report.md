# LifePulse Project Report

## 1. Introduction
LifePulse is a college mini-project demonstrating a direct donor-to-recipient coordination workflow while routing final medical decisions through verified blood banks.

## 2. Problem Statement
People needing blood may have difficulty identifying potential donors quickly. LifePulse provides a centralized software workflow for creating requests, filtering potential donors and coordinating the next step with a blood bank.

## 3. Objectives
- Register donors and recipients securely.
- Create and track blood requests.
- Demonstrate preliminary ABO/Rh matching.
- Sort potential donors by approximate distance.
- Support donor responses.
- Provide verified blood-bank information.
- Demonstrate notification and administrative workflows.

## 4. Architecture
Browser → Flask routes → SQLAlchemy ORM → SQLite database.

Services:
- matching.py: preliminary compatibility and donor ranking.
- distance.py: Haversine distance.
- notification_service.py: in-app notifications.

## 5. Database
Eight tables are used: users, donors, recipients, blood_requests, donor_requests, blood_banks, screenings and notifications.

## 6. Safety
The system never certifies a donor. Final eligibility, compatibility, infection screening and transfusion decisions belong to qualified medical professionals at a licensed blood bank or hospital.

## 7. Testing
The supplied seed database contains fictional demo users, donors, recipients, requests, donor requests, blood banks, screenings and notifications. Main workflows can be demonstrated locally using the supplied accounts.

## 8. Conclusion
LifePulse demonstrates how a web application can streamline non-clinical coordination while keeping medical decisions with qualified professionals.
