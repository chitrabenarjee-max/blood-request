document.addEventListener("DOMContentLoaded", () => {
  const clock = document.getElementById("liveClock");
  if (clock) {
    const tick = () => clock.textContent = new Date().toLocaleString();
    tick(); setInterval(tick, 1000);
  }
});
