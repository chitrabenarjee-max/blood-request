document.addEventListener("DOMContentLoaded", () => {
  document.querySelectorAll(".auto-dismiss").forEach(el => {
    setTimeout(() => { el.classList.remove("show"); }, 4500);
  });
});
