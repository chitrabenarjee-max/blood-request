from . import db

class DonorRequest(db.Model):
    __tablename__ = "donor_requests"
    id = db.Column(db.Integer, primary_key=True)
    recipient_id = db.Column(db.Integer, db.ForeignKey("recipients.id"), nullable=False)
    donor_id = db.Column(db.Integer, db.ForeignKey("donors.id"), nullable=False)
    blood_request_id = db.Column(db.Integer, db.ForeignKey("blood_requests.id"), nullable=False)
    status = db.Column(db.String(20), default="Pending", nullable=False)
    created_at = db.Column(db.DateTime, server_default=db.func.now())
    response_time = db.Column(db.DateTime)
    donor = db.relationship("Donor", back_populates="requests")
    blood_request = db.relationship("BloodRequest", back_populates="donor_requests")
    recipient = db.relationship("Recipient")
    screening = db.relationship("Screening", back_populates="donor_request", uselist=False)
