from . import db

class Recipient(db.Model):
    __tablename__ = "recipients"
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey("users.id"), unique=True, nullable=False)
    emergency_contact = db.Column(db.String(120))
    user = db.relationship("User", back_populates="recipient")
    blood_requests = db.relationship("BloodRequest", back_populates="recipient", cascade="all, delete-orphan")
