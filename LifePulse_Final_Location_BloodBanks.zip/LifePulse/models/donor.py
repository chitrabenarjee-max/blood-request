from . import db

class Donor(db.Model):
    __tablename__ = "donors"
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey("users.id"), unique=True, nullable=False)
    availability = db.Column(db.String(20), default="Available", nullable=False)
    last_donation_date = db.Column(db.Date)
    notes = db.Column(db.Text)
    user = db.relationship("User", back_populates="donor")
    requests = db.relationship("DonorRequest", back_populates="donor")
