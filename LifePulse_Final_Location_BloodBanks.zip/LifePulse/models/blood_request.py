from . import db

class BloodRequest(db.Model):
    __tablename__ = "blood_requests"
    id = db.Column(db.Integer, primary_key=True)
    recipient_id = db.Column(db.Integer, db.ForeignKey("recipients.id"), nullable=False)
    blood_group = db.Column(db.String(5), nullable=False)
    units = db.Column(db.Integer, nullable=False)
    urgency = db.Column(db.String(20), nullable=False)
    hospital_name = db.Column(db.String(160), nullable=False)
    hospital_address = db.Column(db.String(255), nullable=False)
    city = db.Column(db.String(80), nullable=False)
    latitude = db.Column(db.Float)
    longitude = db.Column(db.Float)
    required_date = db.Column(db.Date, nullable=False)
    required_time = db.Column(db.Time, nullable=False)
    notes = db.Column(db.Text)
    status = db.Column(db.String(20), default="Pending", nullable=False)
    created_at = db.Column(db.DateTime, server_default=db.func.now())
    recipient = db.relationship("Recipient", back_populates="blood_requests")
    donor_requests = db.relationship("DonorRequest", back_populates="blood_request", cascade="all, delete-orphan")
