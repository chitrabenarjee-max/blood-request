from flask_login import UserMixin
from werkzeug.security import generate_password_hash, check_password_hash
from . import db

class User(UserMixin, db.Model):
    __tablename__ = "users"
    id = db.Column(db.Integer, primary_key=True)
    full_name = db.Column(db.String(120), nullable=False)
    email = db.Column(db.String(160), unique=True, nullable=False, index=True)
    phone = db.Column(db.String(30), nullable=False)
    password_hash = db.Column(db.String(255), nullable=False)
    role = db.Column(db.String(20), nullable=False)  # donor, recipient, admin
    blood_group = db.Column(db.String(5))
    city = db.Column(db.String(80))
    area = db.Column(db.String(80))
    latitude = db.Column(db.Float)
    longitude = db.Column(db.Float)
    date_of_birth = db.Column(db.Date)
    account_status = db.Column(db.String(20), default="Active", nullable=False)
    created_at = db.Column(db.DateTime, server_default=db.func.now())

    donor = db.relationship("Donor", back_populates="user", uselist=False, cascade="all, delete-orphan")
    recipient = db.relationship("Recipient", back_populates="user", uselist=False, cascade="all, delete-orphan")
    notifications = db.relationship("Notification", back_populates="user", cascade="all, delete-orphan")

    def set_password(self, password):
        self.password_hash = generate_password_hash(password)

    def check_password(self, password):
        return check_password_hash(self.password_hash, password)
