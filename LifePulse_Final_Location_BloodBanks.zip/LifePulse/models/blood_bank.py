from . import db

class BloodBank(db.Model):
    __tablename__ = "blood_banks"
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(160), nullable=False)
    license_id = db.Column(db.String(100), nullable=False)
    address = db.Column(db.String(255), nullable=False)
    city = db.Column(db.String(80), nullable=False)
    phone = db.Column(db.String(30), nullable=False)
    email = db.Column(db.String(160), nullable=False)
    latitude = db.Column(db.Float)
    longitude = db.Column(db.Float)
    verification_status = db.Column(db.String(20), default="Pending", nullable=False)
    screenings = db.relationship("Screening", back_populates="blood_bank")
