from . import db

class Screening(db.Model):
    __tablename__ = "screenings"
    id = db.Column(db.Integer, primary_key=True)
    donor_request_id = db.Column(db.Integer, db.ForeignKey("donor_requests.id"), nullable=False)
    donor_id = db.Column(db.Integer, db.ForeignKey("donors.id"), nullable=False)
    blood_bank_id = db.Column(db.Integer, db.ForeignKey("blood_banks.id"), nullable=False)
    screening_date = db.Column(db.Date, nullable=False)
    hemoglobin_checked = db.Column(db.Boolean, default=False)
    blood_group_confirmed = db.Column(db.Boolean, default=False)
    infection_screening_completed = db.Column(db.Boolean, default=False)
    medical_officer_notes = db.Column(db.Text)
    final_screening_status = db.Column(db.String(30), default="Pending")
    donor_request = db.relationship("DonorRequest", back_populates="screening")
    blood_bank = db.relationship("BloodBank", back_populates="screenings")
    donor = db.relationship("Donor")
