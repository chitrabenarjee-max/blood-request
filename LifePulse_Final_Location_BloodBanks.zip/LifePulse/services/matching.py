from .distance import haversine_km

COMPATIBLE = {
    "O+": ["O+"], "O-": ["O-"],
    "A+": ["A+", "A-", "O+", "O-"],
    "A-": ["A-", "O-"],
    "B+": ["B+", "B-", "O+", "O-"],
    "B-": ["B-", "O-"],
    "AB+": ["A+", "A-", "B+", "B-", "AB+", "AB-", "O+", "O-"],
    "AB-": ["A-", "B-", "AB-", "O-"],
}

DISCLAIMER = "Preliminary compatibility filter — final compatibility must be confirmed by the blood bank."

def compatible_groups(recipient_group):
    return COMPATIBLE.get(recipient_group, [])

def rank_donors(donors, request):
    groups = compatible_groups(request.blood_group)
    results = []
    for donor in donors:
        if donor.user.account_status != "Active" or donor.availability != "Available":
            continue
        if donor.user.blood_group not in groups:
            continue
        dist = haversine_km(request.latitude, request.longitude,
                            donor.user.latitude, donor.user.longitude)
        results.append((donor, dist))
    results.sort(key=lambda x: x[1] if x[1] is not None else 10**9)
    return results
