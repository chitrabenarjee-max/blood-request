import base64, logging, os, smtplib, urllib.parse, urllib.request
from email.message import EmailMessage
from models import db
from models.notification import Notification

log=logging.getLogger(__name__)
def _e(k,d=""): return os.getenv(k,d).strip()

def send_email(to_email, subject, message):
    host=_e("MAIL_SERVER"); user=_e("MAIL_USERNAME"); pwd=_e("MAIL_PASSWORD"); sender=_e("MAIL_FROM",user)
    if not all([host,user,pwd,sender,to_email]): return False
    try:
        m=EmailMessage(); m["Subject"]=subject; m["From"]=sender; m["To"]=to_email; m.set_content(message)
        with smtplib.SMTP(host,int(_e("MAIL_PORT","587")),timeout=15) as server:
            server.starttls(); server.login(user,pwd); server.send_message(m)
        return True
    except Exception: log.exception("Email delivery failed"); return False

def send_sms(to_phone,message):
    sid=_e("TWILIO_ACCOUNT_SID"); token=_e("TWILIO_AUTH_TOKEN"); frm=_e("TWILIO_FROM_NUMBER")
    if not all([sid,token,frm,to_phone]): return False
    try:
        url=f"https://api.twilio.com/2010-04-01/Accounts/{sid}/Messages.json"
        data=urllib.parse.urlencode({"To":to_phone,"From":frm,"Body":message}).encode()
        req=urllib.request.Request(url,data=data,method="POST")
        req.add_header("Authorization","Basic "+base64.b64encode(f"{sid}:{token}".encode()).decode())
        req.add_header("Content-Type","application/x-www-form-urlencoded")
        with urllib.request.urlopen(req,timeout=15) as r: return 200 <= r.status < 300
    except Exception: log.exception("SMS delivery failed"); return False

def notify_user(user,message,kind="info",subject="LifePulse Notification"):
    db.session.add(Notification(user_id=user.id,message=message,type=kind))
    send_email(user.email,subject,message); send_sms(user.phone,message)

def notify(user_id,message,kind="info",subject="LifePulse Notification"):
    from models.user import User
    user=db.session.get(User,user_id)
    if user: notify_user(user,message,kind,subject)
